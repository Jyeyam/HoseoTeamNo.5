package com.main.caloriecalculator;

import com.sun.javafx.charts.Legend;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;

public class Controller {

    /// 왼쪽 레이아웃 Control들
    @FXML
    private TextField first_1_textField;
    @FXML
    private ListView<String> first_1_listView;
    @FXML
    private Button first_1_button;
    @FXML
    private Button first_ReadMore_button;
    @FXML
    private Button first_confirm_button;

    /// 두번째 레이아웃 Control들
    @FXML
    private ListView<String> second_showFoodsIAte_listview;
    @FXML
    private Button second_delete_button;
    @FXML
    private TextArea second_showAllFoods_textArea;

    /// 세번째 레이아웃 Controls들 은 지혜씨한테 받으면 하는걸로
    @FXML
    private ChoiceBox<String> choice_gender;
    @FXML
    private ComboBox choice_age;
    private ObservableList<String> ov = FXCollections.observableArrayList();

    private ObservableList<String> secondListViewOv = FXCollections.observableArrayList();
    private double sumCalorie;

    @FXML
    private TextField heightTextField;
   /* @FXML
    private Button height_button;*/
    @FXML
    private TextField weightTextField;
    @FXML
    private Button compareButton;
    @FXML
    private TextArea resultTextArea;

    @FXML
    public void initialize() {
        sumCalorie = 0;
        choice_gender.setItems(FXCollections.observableArrayList("남성", "여성"));
        choice_gender.setValue("남성");

        ObservableList<Integer> ageList = FXCollections.observableArrayList();
        for (int i = 0; i <= 100; i++) {
            ageList.add(i);
        }
        choice_age.setItems(ageList);
        choice_age.setPromptText("나이");

        second_showFoodsIAte_listview.setItems(secondListViewOv);
        second_delete_button.setOnAction(e -> pressDeleteButton());
    }

    public void pressEnterInTextField() {
        first_1_textField.setOnAction(e -> {
            first_1_button.fire();
            first_1_textField.requestFocus();
        });
    }

    public void pressDeleteButton() {
        String name = second_showFoodsIAte_listview.getSelectionModel().getSelectedItem();

        double calories = extractNumbers(name);
        sumCalorie -= calories;
        System.out.println("sumCalorie = " + sumCalorie);

        secondListViewOv.remove(name);
        ov.remove(name);
    }


    public void confirmButtonMethod() {
        String name = first_1_listView.getSelectionModel().getSelectedItem();
        if (name != null && !ov.contains(name)) {
            ov.add(name);
            if (!secondListViewOv.contains(name)) {
                double calories = extractNumbers(name);
                sumCalorie += calories;
                System.out.println("sumCalorie = " + sumCalorie);
                secondListViewOv.add(name);
            }
        }
    }

    @FXML
    public void buttonClicked() {
        try {
            String input = first_1_textField.getText();
            if (!input.isEmpty()) {
                String result = ApiCall.nameAndCalorie(input);
                updateListView(result);
                first_1_textField.clear();
            }
        } catch (Exception e) {

        }
    }

    private void updateListView(String apiResult) {
        ObservableList<String> items = FXCollections.observableArrayList();
        String[] lines = apiResult.split("\n");

        System.out.println("");
        System.out.println(lines[0]);
        System.out.println(lines[1]);
        System.out.println(lines[2]);
        System.out.println(lines[3]);
        System.out.println("");

        for (int i = 0; i < lines.length; i += 2) {
            if (i + 1 < lines.length) {
                String foodName = lines[i].replace("Food Name: ", "");
                String calories = lines[i + 1].replace("Calories: ", "");
                items.add(foodName + " - " + calories + " kcal");
            }
        }
        first_1_listView.setItems(items);
    }

    private double extractNumbers(String input) {
        double result = 0;
        String onlyDeigits = input.replaceAll("[^0-9.]", "");

        if (!onlyDeigits.isEmpty()) {
            try {
                result = Double.parseDouble(onlyDeigits);
            } catch (NumberFormatException e) {
                e.printStackTrace();
            }
        }
        return result;
    }

    @FXML
    private void compareCalories() {
        String gender = choice_gender.getValue();
        int age = (int) choice_age.getValue();
        double height = Double.parseDouble(heightTextField.getText().trim());
        double weight = Double.parseDouble(weightTextField.getText().trim());

        double consumedCalories = Double.parseDouble(String.valueOf(sumCalorie));
        double recommendedCalories = calculateRecommendedCalories(gender, age, height, weight);; // 적정 칼로리 계산
        double difference = consumedCalories - recommendedCalories;

        String message;
        if (difference > 0) {
            message = String.format("000님의 적정 칼로리는 " + recommendedCalories + "kcal 이고, 적정 칼로리보다 %,.2f kcal 더 섭취했습니다.", difference);
        } else if (difference < 0) {
            message = String.format("000님의 적정 칼로리는 " + recommendedCalories + "kcal 이고, 적정 칼로리보다 %,.2f kcal 덜 섭취했습니다.", Math.abs(difference));
        } else {
            message = "000님은 적정 칼로리 " + recommendedCalories + "kcal 섭취했습니다.";
        }

        resultTextArea.setText(message);
    }

    private double calculateRecommendedCalories(String gender, int age, double height, double weight) {
        // 여기에서 실제 하루 적정 칼로리를 계산하는 로직을 구현합니다.
        // 예시로 BMR 계산식을 사용하겠습니다. (식별자 값이 필요하니 남성일때 '남성' 여성일때 '여성'으로 하겠습니다.)
        double bmr;
        if (gender.equals("남성")) {
            bmr = 66.47 + (13.75 * weight) + (5 * height) - (6.76 * age);
        } else {
            bmr = 655.1 + (9.56 * weight) + (1.85 * height) - (4.68 * age);
        }
        return bmr;
    }
}